var bananaImage,
backImage,
    scene,
    ground,
    foodGroup,
    obstacleGroup,
player_running,
obstacleImage,
obstacle_group,
score;

function preload(){
  
backImage = loadImage("jungle.jpg");
  
 player_running = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");

bananaImage = loadImage("banana.png");
  
ObstacleImage = loadImage("stone.png");


}

function setup() {
  createCanvas(400, 400);
  
  scene = createSprite(0,30,400,400);
   player = createSprite(60,260,20,20);
   ground = createSprite(400,300,800,10);
  
  scene.addImage(backImage);
  
  scene.velocityX = -2;
  
  obastacleGroup = new Group();
  
   scene.x = scene.width/2;
  
  ground.visible = false;
  
  player.addAnimation("running",player_running);
  player.scale = 0.13;
  
  foodGroup = new Group();
  obstacleGroup = new Group(); 

  score = 0;
}

function draw() {
  background(50);
  player.collide(ground);
  
  if(keyDown("space")&& player.y>=250){
    
    player.velocityY = -17 ;
  }
  
  //addgravity
  player.velocityY = player.velocityY + 1;
   
if(scene.x < 0){
      scene.x = scene.width/2;
}
  food();
  obstacles()
  
  if(foodGroup.isTouching(player)){
    score = score + 2;
    foodGroup.destroyEach();
  }
  banana_scale()
  
  if(obstacleGroup.isTouching(player)){
    player.scale = 0.11;
}
  drawSprites();
  
  stroke("white");
  textSize(20);
  fill("white");
  text("score:"+ score, 400,50);
  
}

function food(){
  if(frameCount%99 ===0){
    
  var food = createSprite(602,120,30,30);
    food.y = Math.round(random(120,193));
    food.addImage(bananaImage);

    food.velocityX = -3;
    food.scale = 0.08;
  
   foodGroup.add(food);
  }
}

function obstacles(){
  
   if(frameCount % 91 === 0){
     
     var obstacle = createSprite(350,280,20,20);
     obstacle.x = Math.round(random(185,350));
     obstacle.addImage(ObstacleImage);
     obstacle.scale = 0.15;
     obstacle.lifetime = 500;
     obstacle.velocityX = -4;

     obstacleGroup.add(obstacle);
   }
}

function banana_scale(){
switch(score){
  case 10 : player.scale = 0.14;
    break;
    
  case 20 : player.scale = 0.16;
    break;
    
  case 30 : player.scale = 0.18;
    break;

  case 10 : player.scale = 0.20;
   break;
   default: break;
    

}
}